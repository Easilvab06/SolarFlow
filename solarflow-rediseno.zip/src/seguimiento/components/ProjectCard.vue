<script setup>
import { computed } from 'vue'
import { STATUSES, ALARM_LEVELS, projectCode, formatDate } from '../data/mockData.js'
import StatusBadge from './StatusBadge.vue'
import TeamAvatars from './TeamAvatars.vue'
import ProgressRing from './ProgressRing.vue'

const props = defineProps({
  project: { type: Object, required: true },
})

const emit = defineEmits(['open', 'delete'])

const status = computed(() => STATUSES[props.project.status])
const alarm = computed(() => ALARM_LEVELS[props.project.alarmLevel])
const activeAlarms = computed(
  () => props.project.alarms?.filter((a) => !a.resolved).length ?? 0,
)

// Riel lateral: refleja el estado de alarma para escanear el tablero de un vistazo.
const railClass = computed(() => {
  if (props.project.alarmLevel === 'roja') return 'bg-rose-500'
  if (props.project.alarmLevel === 'amarilla') return 'bg-amber-400'
  return 'bg-navy-100'
})
</script>

<template>
  <div
    role="button"
    tabindex="0"
    class="group relative flex w-full cursor-pointer overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-navy-900/5 transition-all duration-200 hover:-translate-y-1 hover:shadow-card-hover focus:outline-none focus-visible:ring-2 focus-visible:ring-solar-400"
    @click="emit('open', project)"
    @keydown.enter.prevent="emit('open', project)"
    @keydown.space.prevent="emit('open', project)"
  >
    <!-- Riel de estado / alarma -->
    <span class="w-1.5 flex-none" :class="railClass" />

    <div class="min-w-0 flex-1 p-5">
      <!-- Fila superior: código + estado + alarma -->
      <div class="flex items-start justify-between gap-2">
        <div class="flex min-w-0 items-center gap-2">
          <span class="font-mono text-[11px] font-medium tracking-tight text-navy-300">
            {{ projectCode(project.id) }}
          </span>
          <StatusBadge :config="status" />
        </div>
        <div class="flex flex-none items-center gap-1.5">
          <span
            v-if="activeAlarms"
            class="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold"
            :class="[alarm.badge, project.alarmLevel === 'roja' ? 'animate-pulseRing' : '']"
          >
            <svg class="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <path d="M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
            </svg>
            {{ activeAlarms }}
          </span>
          <button
            class="flex h-7 w-7 items-center justify-center rounded-lg text-navy-200 opacity-0 transition-all hover:bg-rose-50 hover:text-rose-500 group-hover:opacity-100 focus:opacity-100"
            title="Eliminar proyecto"
            @click.stop="emit('delete', project)"
          >
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14" />
            </svg>
          </button>
        </div>
      </div>

      <!-- Cuerpo: título + gauge -->
      <div class="mt-3 flex items-start justify-between gap-4">
        <div class="min-w-0">
          <h3 class="font-display text-[15px] font-semibold leading-snug text-navy-900">
            {{ project.name }}
          </h3>
          <p class="mt-1 flex items-center gap-1.5 text-[13px] text-navy-400">
            <svg class="h-3.5 w-3.5 flex-none text-navy-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
              <circle cx="12" cy="10" r="3" />
            </svg>
            <span class="truncate">{{ project.client }} · {{ project.location }}</span>
          </p>
        </div>
        <ProgressRing :value="project.progress" :size="58" :stroke="5" class="flex-none" />
      </div>

      <!-- Línea divisoria fina -->
      <div class="mt-4 border-t border-dashed border-navy-100" />

      <!-- Footer: equipo + ventana temporal + CTA -->
      <div class="mt-3 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <TeamAvatars :team="project.team" size="sm" :max="3" />
        </div>
        <div class="flex items-center gap-3">
          <span class="hidden font-mono text-[11px] text-navy-300 sm:inline">
            {{ formatDate(project.dates.end) }}
          </span>
          <span
            class="flex items-center gap-1 text-[13px] font-semibold text-solar-500 opacity-0 transition-opacity group-hover:opacity-100"
          >
            Abrir
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <path d="M5 12h14m0 0-6-6m6 6-6 6" />
            </svg>
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
