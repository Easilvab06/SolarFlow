<script setup>
/**
 * App.vue — Demo de integración.
 * -----------------------------------------------------------------------------
 * Reproduce el portal de módulos de la plataforma. Al abrir una categoría,
 * monta el módulo <SeguimientoProyectos> pasándole la categoría seleccionada.
 * En una app real esto se haría con Vue Router (ver README).
 * -----------------------------------------------------------------------------
 */
import { ref, computed } from 'vue'
import SeguimientoProyectos from './seguimiento/SeguimientoProyectos.vue'
import { MOCK_PROJECTS } from './seguimiento/data/mockData.js'

// Categorías del portal (íconos como SVG inline para no depender de librerías).
const categories = [
  {
    name: 'Cotizador EPC',
    desc: 'Cotizaciones de sistemas fotovoltaicos EPC.',
    tile: 'text-rose-500',
    tileBg: 'bg-rose-50 group-hover:bg-rose-100',
    icon: 'M13 2 3 14h7l-1 8 10-12h-7l1-8Z',
  },
  {
    name: 'Cotización y Suministro',
    desc: 'Pipeline de cotizaciones y suministro de equipos.',
    tile: 'text-orange-500',
    tileBg: 'bg-orange-50 group-hover:bg-orange-100',
    icon: 'M21 8 12 3 3 8m18 0-9 5-9-5m18 0v8l-9 5-9-5V8',
  },
  {
    name: 'Mantenimiento General',
    desc: 'O&M solar fotovoltaico — preventivo y correctivo.',
    tile: 'text-emerald-500',
    tileBg: 'bg-emerald-50 group-hover:bg-emerald-100',
    icon: 'm12 20 8-8-4-4-8 8v4h4Zm4-12 2-2 4 4-2 2',
  },
  {
    name: 'EDC',
    desc: 'Estaciones de carga para vehículos eléctricos.',
    tile: 'text-violet-500',
    tileBg: 'bg-violet-50 group-hover:bg-violet-100',
    icon: 'M5 17h14M6 17V9l2-4h8l2 4v8M7 21v-2m10 2v-2M8 9h8',
  },
  {
    name: 'Interventoría y Consultoría',
    desc: 'Consultoría técnica e interventoría de proyectos.',
    tile: 'text-amber-500',
    tileBg: 'bg-amber-50 group-hover:bg-amber-100',
    icon: 'M9 12h6m-6 4h6M9 8h6M5 4h14v16H5z',
  },
  {
    name: 'Ingeniería',
    desc: 'Diseño e ingeniería de proyectos solares.',
    tile: 'text-sky-500',
    tileBg: 'bg-sky-50 group-hover:bg-sky-100',
    icon: 'M4 20 20 4M4 20h6M4 20v-6',
  },
  {
    name: 'Eficiencia Energética',
    desc: 'Proyectos de eficiencia y ahorro energético.',
    tile: 'text-yellow-500',
    tileBg: 'bg-yellow-50 group-hover:bg-yellow-100',
    icon: 'M9 21h6m-5 0v-3m4 3v-3M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.3 1 2.5h6c0-1.2.3-1.8 1-2.5A6 6 0 0 0 12 3Z',
  },
]

// Conteo real de proyectos por categoría, para que cada módulo muestre su carga.
const countByCategory = computed(() => {
  const map = {}
  for (const p of MOCK_PROJECTS) map[p.category] = (map[p.category] || 0) + 1
  return map
})

const totalProjects = MOCK_PROJECTS.length
const activeAlarms = MOCK_PROJECTS.reduce(
  (acc, p) => acc + (p.alarms?.filter((a) => !a.resolved).length ?? 0),
  0,
)

const selectedCategory = ref(null)

function open(cat) {
  selectedCategory.value = cat.name
}
function back() {
  selectedCategory.value = null
}
</script>

<template>
  <!-- Módulo de seguimiento (cuando hay categoría seleccionada) -->
  <SeguimientoProyectos
    v-if="selectedCategory"
    :category-name="selectedCategory"
    @back="back"
    @project-created="(p) => console.log('Proyecto creado:', p)"
    @project-updated="(p) => console.log('Proyecto actualizado:', p)"
  />

  <!-- Portal de módulos (vista principal) -->
  <main v-else class="min-h-screen bg-navy-50 bg-grid-light bg-grid">
    <!-- Barra de marca -->
    <div class="border-b border-navy-100 bg-white/80 backdrop-blur">
      <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <div class="flex items-center gap-2.5">
          <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-navy-900 text-solar-400">
            <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
              <circle cx="12" cy="12" r="4" />
              <path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
            </svg>
          </span>
          <span class="font-display text-base font-bold tracking-tight text-navy-900">SolarFlow</span>
        </div>
        <p class="hidden font-mono text-[11px] text-navy-400 sm:block">Plataforma de gestión energética</p>
      </div>
    </div>

    <!-- Héroe sala de control -->
    <section class="relative overflow-hidden bg-control">
      <span class="pointer-events-none absolute -left-20 -top-24 h-72 w-72 animate-floatGlow rounded-full bg-solar-400/15 blur-3xl" />
      <span class="pointer-events-none absolute -right-10 top-10 h-56 w-80 rounded-full bg-sky-500/10 blur-3xl" />
      <div class="pointer-events-none absolute inset-x-0 top-0 h-px overflow-hidden">
        <span class="block h-px w-1/4 animate-sheen bg-solar-sheen" />
      </div>

      <div class="relative mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
        <p class="font-mono text-[11px] font-medium uppercase tracking-[0.25em] text-solar-300">
          Sala de control · Boyacá
        </p>
        <h1 class="mt-3 max-w-2xl font-display text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
          Seguimiento y control de tus proyectos de energía, en un solo lugar.
        </h1>
        <p class="mt-3 max-w-xl text-[15px] leading-relaxed text-navy-200">
          Abre un módulo para ver el estado en vivo de sus proyectos, cargar evidencias
          y atender alarmas antes de que se conviertan en retrasos.
        </p>

        <!-- Lecturas del portal -->
        <div class="mt-8 flex flex-wrap items-center gap-6">
          <div>
            <p class="font-mono text-2xl font-bold tabular text-white">{{ categories.length }}</p>
            <p class="text-[11px] font-medium uppercase tracking-wide text-navy-300">Módulos</p>
          </div>
          <span class="h-8 w-px bg-white/10" />
          <div>
            <p class="font-mono text-2xl font-bold tabular text-white">{{ totalProjects }}</p>
            <p class="text-[11px] font-medium uppercase tracking-wide text-navy-300">Proyectos</p>
          </div>
          <span class="h-8 w-px bg-white/10" />
          <div>
            <p class="font-mono text-2xl font-bold tabular text-rose-300">{{ activeAlarms }}</p>
            <p class="text-[11px] font-medium uppercase tracking-wide text-navy-300">Alarmas activas</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Módulos -->
    <div class="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div class="mb-5 flex items-baseline justify-between">
        <h2 class="font-display text-lg font-bold text-navy-900">Módulos del sistema</h2>
        <p class="text-sm text-navy-400">Selecciona una categoría para gestionar su seguimiento.</p>
      </div>

      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <button
          v-for="(cat, i) in categories"
          :key="cat.name"
          class="group relative flex animate-rise flex-col overflow-hidden rounded-2xl bg-white p-6 text-left shadow-card ring-1 ring-navy-900/5 transition-all duration-200 hover:-translate-y-1 hover:shadow-card-hover focus:outline-none focus-visible:ring-2 focus-visible:ring-solar-400"
          :style="{ animationDelay: Math.min(i * 55, 380) + 'ms' }"
          @click="open(cat)"
        >
          <!-- Acento superior que aparece al hover -->
          <span class="absolute inset-x-0 top-0 h-0.5 origin-left scale-x-0 bg-solar-400 transition-transform duration-300 group-hover:scale-x-100" />

          <div class="flex items-start justify-between">
            <span
              class="flex h-12 w-12 items-center justify-center rounded-xl transition-colors"
              :class="[cat.tile, cat.tileBg]"
            >
              <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                <path :d="cat.icon" />
              </svg>
            </span>
            <span
              v-if="countByCategory[cat.name]"
              class="rounded-md bg-navy-50 px-2 py-1 font-mono text-[11px] font-semibold text-navy-500 ring-1 ring-navy-100"
            >
              {{ countByCategory[cat.name] }} {{ countByCategory[cat.name] === 1 ? 'proyecto' : 'proyectos' }}
            </span>
          </div>

          <h3 class="mt-4 font-display text-base font-semibold text-navy-900">{{ cat.name }}</h3>
          <p class="mt-1 text-sm leading-relaxed text-navy-400">{{ cat.desc }}</p>

          <span class="mt-4 flex items-center gap-1 text-[13px] font-semibold text-solar-500 opacity-0 transition-opacity group-hover:opacity-100">
            Abrir módulo
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <path d="M5 12h14m0 0-6-6m6 6-6 6" />
            </svg>
          </span>
        </button>
      </div>

      <p class="mt-8 text-center font-mono text-[11px] text-navy-300">
        Demo de integración · haz clic en cualquier módulo para abrir el seguimiento.
      </p>
    </div>
  </main>
</template>
