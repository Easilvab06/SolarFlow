/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        // UI / cuerpo
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        // Títulos y etiquetas técnicas
        display: ['"Space Grotesk"', 'Inter', 'ui-sans-serif', 'sans-serif'],
        // Lecturas de instrumento: números, códigos, fechas, %
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      colors: {
        // Navy = celda fotovoltaica / sala de control
        navy: {
          50: '#F0F4FA',
          100: '#DBE4F0',
          200: '#B7C8E0',
          300: '#8AA4C6',
          400: '#5A78A3',
          500: '#3A567F',
          600: '#2A4064',
          700: '#1E2F4D',
          800: '#152238',
          900: '#0E1A2B',
          950: '#0A1220',
        },
        // Solar = energía, sol, cosecha. Acento de marca.
        solar: {
          50: '#FEF6E7',
          100: '#FDE9C2',
          200: '#FBD488',
          300: '#F9BE4E',
          400: '#F5A524',
          500: '#E08A0B',
          600: '#B96C07',
          700: '#8F520A',
        },
        // Alias que ya usaba AlarmsPanel — apuntan al acento solar
        gold: {
          50: '#FEF6E7',
          100: '#FDE9C2',
          200: '#FBD488',
          300: '#F9BE4E',
          400: '#F5A524',
          500: '#E08A0B',
          600: '#B96C07',
        },
      },
      boxShadow: {
        card: '0 1px 2px rgba(14,26,43,0.05), 0 10px 26px -14px rgba(14,26,43,0.20)',
        'card-hover': '0 2px 6px rgba(14,26,43,0.08), 0 22px 44px -18px rgba(14,26,43,0.32)',
        glass: '0 24px 60px -24px rgba(10,18,32,0.55)',
        solar: '0 0 0 1px rgba(245,165,36,0.35), 0 10px 34px -10px rgba(245,165,36,0.55)',
        inset: 'inset 0 1px 0 rgba(255,255,255,0.06)',
      },
      backgroundImage: {
        'grid-dark':
          'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.055) 1px, transparent 0)',
        'grid-light':
          'radial-gradient(circle at 1px 1px, rgba(30,47,77,0.05) 1px, transparent 0)',
        'solar-sheen':
          'linear-gradient(90deg, transparent, rgba(245,165,36,0.85), transparent)',
      },
      backgroundSize: {
        grid: '22px 22px',
      },
      keyframes: {
        rise: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        sheen: {
          '0%': { transform: 'translateX(-120%)' },
          '100%': { transform: 'translateX(320%)' },
        },
        pulseRing: {
          '0%': { boxShadow: '0 0 0 0 rgba(229,72,77,0.5)' },
          '70%': { boxShadow: '0 0 0 7px rgba(229,72,77,0)' },
          '100%': { boxShadow: '0 0 0 0 rgba(229,72,77,0)' },
        },
        floatGlow: {
          '0%,100%': { transform: 'translate(0,0)', opacity: '0.55' },
          '50%': { transform: 'translate(6px,-8px)', opacity: '0.8' },
        },
      },
      animation: {
        rise: 'rise 0.5s cubic-bezier(0.22,1,0.36,1) both',
        sheen: 'sheen 2.6s ease-in-out infinite',
        pulseRing: 'pulseRing 1.8s ease-out infinite',
        floatGlow: 'floatGlow 7s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
